Welcome to CSS Hat 2, the best and fastest way to move layer styles to CSS!

Important note: Photoshop 15 (CC2014) or 16 (CC2015) is required! You will need CSS Hat 1 for older versions of Photoshop.

Installation:
	1. Close your Photoshop if it’s running.

	2. Copy "extension/com.madebysource.csshat2" folder into Photoshop CEP Extension folder.
		- On Mac: /Users/<USERNAME>/Library/Application Support/Adobe/CEP/extensions/
		- On Windows: C:\Users\<USERNAME>\AppData\Roaming\Adobe\CEP\extensions\

	3. Copy "generator/com.madebysource.csshat2" folder into Photoshop Generator folder.
		- On Mac: /Applications/Adobe Photoshop CC <2014 or 2015>/Plug-ins/Generator/
		- On Windows: C:\Program Files\Adobe\Adobe Photoshop CC <2014 or 2015>\Plug-ins\Generator\

	4. You will find CSS Hat Panel in Photoshop under Window > Extensions > CSS Hat

	5. Enjoy!

	6. Please report bugs to support@csshat.com
	
	7. You could also help us by sending the installation log file `source-install.log` located in your home directory.
	   You can navigate to your home directory by pressing cmd+shift+H in any Finder window (on Mac) or go to `C:\Users\<USERNAME>\` (on Windows).
