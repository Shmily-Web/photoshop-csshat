
function getDocumentSelection() {
  var bounds = null;
  var ruller_unit = app.preferences.rulerUnits;
  app.preferences.rulerUnits = Units.PIXELS;

  try {
    bounds = app.activeDocument.selection.bounds;
  } catch (e) {}

  app.preferences.rulerUnits = ruller_unit;

  return bounds;
}

var b = getDocumentSelection();
if (b)
  '{"bounds": [' + parseInt(b[0]) + ',' + parseInt(b[1]) + ',' + parseInt(b[2]) + ',' + parseInt(b[3]) + ']}'
