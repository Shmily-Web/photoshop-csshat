
function openFile(path) {
  var file = new File(path);
  if (file.exists)
    app.open(file);
}

openFile(params.path);
