# pnghat

This is a Panel that does something useful.

## Development

- Clone both repositories `pnghat-photoshop` and `pnghat-panel` next to each other.
- Go into `pnghat-photoshop` and run `npm link ../pnghat-panel` to connect them together.
- When adding dependencies, install them with `npm install <dep> --save` and don't forget to add them to `bundledDependencies` in `package.json`, otherwise they wouldn't made it into production build.
- Use `npm start` to test run Panel. Photoshop must bu running and [properly configured](https://upx.cz/np61imah6g8lj19ktb9pzx12a6pgdqaw1tcuttqm) in order to test Panels.

## Distribution

- Use `npm pack` to create distribution bundle.
