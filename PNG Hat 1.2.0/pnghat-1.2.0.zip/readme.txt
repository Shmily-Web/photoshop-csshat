**You have just opened README of PNG Hat v1.2.0**

Important: Photoshop 15.1+ version (CC2014.1+ or CC2015) is required! If you need to install PNG Hat to an older version of Photoshop, download this zipfile: https://madebysource.com/download/pnghat/zip/10001/

Installation:
	1. Close your Photoshop if it’s running.

	2. Copy "com.madebysource.pnghat" from "extension" folder into Photoshop CEP Extension folder.
		- On Mac: /Users/<USERNAME>/Library/Application Support/Adobe/CEP/extensions/
		- On Windows: C:\Users\<USERNAME>\AppData\Roaming\Adobe\CEP\extensions\

	3. Copy "com.madebysource.pnghat" from "generator.mac" or "generator.windows" folder into Photoshop Generator folder.
		- On Mac: /Applications/Adobe Photoshop CC <2014 or 2015>/Plug-ins/Generator/
		- On Windows: C:\Program Files\Adobe\Adobe Photoshop CC <2014 or 2015>\Plug-ins\Generator\
	
	4. You will find PNG Hat Panel in Photoshop under Window > Extensions > PNG Hat

	5. Enjoy!

	6. Please report bugs to team@madebysource.com
	
	7. You could also help us by sending the installation log file `source-install.log` located in your home directory.
	   You can navigate to your home directory by pressing cmd+shift+H in any Finder window (on Mac) or go to `C:\Users\<USERNAME>\` (on Windows).
